/* This is a sample custom javascript file.  Copy it to ubermenu/custom/custom.js and enable it in the
 * UberMenu Advanced Settings Panel to use
 */

jQuery( document ).ready( function( $ ) {

	/* Your code here */
	alert( 'Custom JS Loaded Properly' ); //Delete once it's loaded correctly

});